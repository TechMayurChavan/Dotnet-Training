﻿namespace Web_App_Job_Seeker.Models
{
    public class UserInRole
    {
        public string UserId { get; set; }
        public string RoleId { get; set; }
    }
}
